package az.uwb.automation.statusdatapatching;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import lombok.Getter;
import lombok.Setter;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class GenerateIncCollection {
    public Boolean getWebServeiceTimeout() {
        return webServeiceTimeout;
    }

    public void setWebServeiceTimeout(Boolean webServeiceTimeout) {
        this.webServeiceTimeout = webServeiceTimeout;
    }

    private Boolean webServeiceTimeout;
    public void generate(List<Model> models) throws Exception {
        Map<String, List<Model>> incidents = new TreeMap<>();
        models.stream().forEach(m -> {
            //System.out.println(m.getPolicyNum());
            if (incidents.containsKey(m.getTicket()))
                incidents.get(m.getTicket()).add(m);
            else incidents.put(m.getTicket().toString(), new ArrayList<>(List.of(m)));
        });

        ObjectMapper mapper = new ObjectMapper().enable(SerializationFeature.INDENT_OUTPUT);
        incidents.keySet().forEach(incidentNo -> {
            Map<String, Object> classic = buildClassicCollection(incidentNo, incidents.get(incidentNo));

            //incidents.get(incidentNo).stream().forEach(System.out::println);
            try {
                writeJson(mapper, classic, incidentNo+".postman_collection.json");
            } catch (Exception e) {
                throw new RuntimeException(e);
            }

            System.out.println("Wrote files:");
            System.out.println(" - " + new File(incidentNo+".postman_collection.json").getAbsolutePath());
            System.out.println("\nImport either file in Postman (Collections → Import → File).");
        });



    }

    private static void writeJson(ObjectMapper mapper, Map<String, Object> data, String fileName) throws Exception {
        mapper.writeValue(new File(fileName), data);
        // Optional: validate UTF-8 write by reading back (not strictly necessary)
        byte[] bytes = java.nio.file.Files.readAllBytes(new File(fileName).toPath());
        if (!StandardCharsets.UTF_8.newEncoder().canEncode(new String(bytes, StandardCharsets.UTF_8))) {
            throw new RuntimeException("File encoding check failed for " + fileName);
        }
    }

    // ---------- Classic tests (tests[...] / responseCode / responseBody) ----------
    private Map<String, Object> buildClassicCollection(String incidentNo, List<Model> items) {
        Map<String, Object> root = new LinkedHashMap<>();
        root.put("info", Map.of(
                "name", incidentNo,
                "schema", "https://schema.getpostman.com/json/collection/v2.1.0/collection.json"
        ));

        List<Object> topItems = new ArrayList<>();

        items.forEach(item -> {
            System.out.println(item);

            Map<String, Object> folder = new LinkedHashMap<>();
                folder.put("name", item.getPolicyNum());

            Map<String, Object> url = new LinkedHashMap<>();
                url.put("raw", "https://{{underwriter-api-url}}/uw/underwriter-service/underwritercases/"+item.getDocID());
                url.put("protocol", "https");
                url.put("host", Collections.singletonList("{{underwriter-api-url}}"));
                url.put("path", Arrays.asList("uw", "underwriter-service", "underwritercases", item.getDocID()));

            List<Object> requests = new ArrayList<>();
            // 1. GET - Before Patch
                requests.add(buildClassicRequestItem(
                        "1.Before Patch "+item.getPolicyNum()+" Policy",
                        "GET",
                        null, // body
                        Arrays.asList(
                                Map.of("key", "Authorization", "value", "{{cognitoIdToken}}"),
                                Map.of("key", "X-Api-Key", "value", "{{x-api-key}}")
                        ),
                        url,
                        Arrays.asList(
                                Map.of(
                                        "listen", "test",
                                        "script", Map.of(
                                                "type", "text/javascript",
                                                "exec", Arrays.asList(
                                                        "tests[\"Status code is 200\"] = responseCode.code === 200;",
                                                        "var rdata = JSON.parse(responseBody);",
                                                        "tests[\"Policy number is "+item.getPolicyNum()+"\"] = rdata[\"proposalNumber\"] === \""+item.getPolicyNum()+"\";",
                                                        "tests[\"Policy Status is "+item.getCurrentStatus()+"\"] = rdata[\"documentStatus\"] === \""+item.getCurrentStatus()+"\";"
                                                )
                                        )
                                )
                        )
                ));

            // 2. PATCH - Auto Approve (UW Pause)
            Map<String, Object> patchBody = Map.of(
                    "mode", "raw",
                    "raw", "{" +
                            "\n  \"documentStatus\": \""+item.getCorrectStatus()+"\"" +
                            "}",
                    "options", Map.of("raw", Map.of("language", "json"))
            );

            if (webServeiceTimeout){
                patchBody = Map.of(
                        "mode", "raw",
                        "raw", "{" +
                                "\n  \"documentStatus\": \""+item.getCorrectStatus()+"\"," +
                                "\n  \"assignedTo\": \"Auto Underwriter\"," +
                                "\n  \"underwriterDate\": \""+item.getUwdate()+"\"\n" +
                                "}",
                        "options", Map.of("raw", Map.of("language", "json"))
                );
            }


            List<Object> patchEvents = new ArrayList<>();
            patchEvents.add(Map.of(
                    "listen", "test",
                    "script", Map.of(
                            "type", "text/javascript",
                            "exec", Arrays.asList(
                                    "tests[\"Status code is 200\"] = responseCode.code === 200;",
                                    "var rdata = JSON.parse(responseBody);",
                                    "tests[\"Policy number is "+item.getPolicyNum()+"\"] = rdata[\"proposalNumber\"] === \""+item.getPolicyNum()+"\";",
                                    "tests[\"Policy Status is "+item.getCorrectStatus()+"\"] = rdata[\"documentStatus\"] === \""+item.getCorrectStatus()+"\";"
                            )
                    )
            ));

            patchEvents.add(Map.of(
                    "listen", "prerequest",
                    "script", Map.of(
                            "type", "text/javascript",
                            "exec", Collections.emptyList()
                    )
            ));

            if (webServeiceTimeout)
                requests.add(buildClassicRequestItem(
                        "1.Patch status "+item.getCorrectStatus()+" & Underwriterdate",
                        "PATCH",
                        patchBody,
                        Arrays.asList(
                                Map.of("key", "Authorization", "value", "{{cognitoIdToken}}"),
                                Map.of("key", "X-Api-Key", "value", "{{x-api-key}}")
                        ),
                        url,
                        patchEvents
                ));
            else
                requests.add(buildClassicRequestItem(
                        "1.Patch status "+item.getCorrectStatus(),
                        "PATCH",
                        patchBody,
                        Arrays.asList(
                                Map.of("key", "Authorization", "value", "{{cognitoIdToken}}"),
                                Map.of("key", "X-Api-Key", "value", "{{x-api-key}}")
                        ),
                        url,
                        patchEvents
                ));

            folder.put("item", requests);
            topItems.add(folder);

        });
        root.put("item", topItems);

        return root;
    }


    // ---------- Helper builders ----------
    private static Map<String, Object> buildClassicRequestItem(
            String name,
            String method,
            Map<String, Object> body,
            List<Map<String, Object>> headers,
            Map<String, Object> url,
            List<Object> events
    ) {
        Map<String, Object> item = new LinkedHashMap<>();
        item.put("name", name);

        Map<String, Object> request = new LinkedHashMap<>();
        request.put("method", method);
        request.put("header", headers);
        if (body != null) request.put("body", body);
        request.put("url", url);
        item.put("request", request);

        if (events != null && !events.isEmpty()) item.put("event", events);

        item.put("response", new ArrayList<>()); // empty array
        return item;
    }
}
