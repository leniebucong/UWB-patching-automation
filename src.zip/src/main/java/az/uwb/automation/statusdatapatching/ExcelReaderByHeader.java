package az.uwb.automation.statusdatapatching;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileInputStream;
import java.io.InputStream;
import java.nio.file.Path;
import java.util.*;

public class ExcelReaderByHeader {

    static Scanner scanner = new Scanner(System.in);
    public static void main(String[] args) throws Exception {

        while  (true)
            run();
    }

    private static Boolean run() throws Exception {
        System.out.println("Input Option: (1: status, 2: date and status)");
        GenerateIncCollection generateIncCollection = new GenerateIncCollection();

        if (scanner.hasNextLine()) {
            String input = scanner.nextLine();
            if (input.equals("2"))
                generateIncCollection.setWebServeiceTimeout(true);

            else if (input.equals("1"))
                generateIncCollection.setWebServeiceTimeout(false);

            else {
                System.out.println("Invalid Input. Try Again!");
                return true;
            }
            Path file = Path.of("D:\\MAT\\work-automation\\sdp\\policies\\tmp\\codes\\For UWB patching automation\\Input File.xlsx");     // <-- change to your file
            String sheetName = "Sheet";          // <-- or use index 0
            List<Map<String, Object>> rows = readSheetAsMaps(file.toString(), sheetName);
            List<Model> models = new ArrayList<>();
            // Print preview
            rows.stream().forEach(c -> {
                Model model = new Model();
                model.setTicket(c.get("Ticket").toString());
                model.setCorrectStatus(c.get("Correct Status").toString());
                model.setCurrentStatus(c.get("Current Status").toString());
                model.setDocID(c.get("Document ID").toString());
                model.setPolicyNum(c.get("Policy Num").toString());
                model.setUwdate(c.get("UW Submission Date").toString());
                models.add(model);
            });
            models.forEach(System.out::println);
            generateIncCollection.generate(models);
            System.out.println("Rows read: " + rows.size());
        }
        return true;
    }

    public static List<Map<String, Object>> readSheetAsMaps(String filePath, String sheetName) throws Exception {
        try (InputStream in = new FileInputStream(filePath);
             Workbook wb = new XSSFWorkbook(in)) {

            Sheet sheet = (sheetName != null) ? wb.getSheet(sheetName) : wb.getSheetAt(0);
            if (sheet == null) throw new IllegalArgumentException("Sheet not found: " + sheetName);

            DataFormatter fmt = new DataFormatter();                // human-friendly strings for cells
            FormulaEvaluator evaluator = wb.getCreationHelper().createFormulaEvaluator();

            Iterator<Row> rowIt = sheet.rowIterator();
            if (!rowIt.hasNext()) return Collections.emptyList();

            // Read header row
            Row headerRow = rowIt.next();
            List<String> headers = new ArrayList<>();
            for (int c = 0; c < headerRow.getLastCellNum(); c++) {
                Cell cell = headerRow.getCell(c, Row.MissingCellPolicy.RETURN_BLANK_AS_NULL);
                headers.add(cell != null ? fmt.formatCellValue(cell) : "Column" + (c + 1));
            }

            // Read data rows
            List<Map<String, Object>> result = new ArrayList<>();
            while (rowIt.hasNext()) {
                Row r = rowIt.next();
                if (isRowEmpty(r)) continue;

                Map<String, Object> map = new LinkedHashMap<>();
                for (int c = 0; c < headers.size(); c++) {
                    String key = headers.get(c);
                    Object value = readCellValue(r.getCell(c, Row.MissingCellPolicy.RETURN_BLANK_AS_NULL), fmt, evaluator);
                    map.put(key, value);
                }
                result.add(map);
            }
            return result;
        }
    }

    private static Object readCellValue(Cell cell, DataFormatter fmt, FormulaEvaluator evaluator) {
        if (cell == null) return null;

        // Evaluate formulas
        if (cell.getCellType() == CellType.FORMULA) {
            CellValue cv = evaluator.evaluate(cell);
            if (cv == null) return null;
            return switch (cv.getCellType()) {
                case STRING -> cv.getStringValue();
                case NUMERIC -> DateUtil.isCellDateFormatted(cell) ? cell.getDateCellValue() : cv.getNumberValue();
                case BOOLEAN -> cv.getBooleanValue();
                case BLANK -> null;
                default -> fmt.formatCellValue(cell);
            };
        }

        return switch (cell.getCellType()) {
            case STRING -> cell.getStringCellValue();
            case NUMERIC -> DateUtil.isCellDateFormatted(cell) ? cell.getDateCellValue() : cell.getNumericCellValue();
            case BOOLEAN -> cell.getBooleanCellValue();
            case BLANK -> null;
            case ERROR -> "(ERROR:" + cell.getErrorCellValue() + ")";
            default -> fmt.formatCellValue(cell);
        };
    }

    private static boolean isRowEmpty(Row row) {
        if (row == null) return true;
        for (int c = row.getFirstCellNum(); c < row.getLastCellNum(); c++) {
            Cell cell = row.getCell(c, Row.MissingCellPolicy.RETURN_BLANK_AS_NULL);
            if (cell != null && cell.getCellType() != CellType.BLANK) return false;
        }
        return true;
    }
}
