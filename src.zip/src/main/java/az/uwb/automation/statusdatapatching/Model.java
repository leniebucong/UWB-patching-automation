package az.uwb.automation.statusdatapatching;

import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

public class Model {

    private String policyNum, ticket, currentStatus, docID, correctStatus, uwdate;

    public String getPolicyNum() {
        return policyNum;
    }

    public void setPolicyNum(String policyNum) {
        this.policyNum = policyNum;
    }

    public String getTicket() {
        return ticket;
    }

    public void setTicket(String ticket) {
        this.ticket = ticket;
    }

    public String getCurrentStatus() {
        return currentStatus;
    }

    public void setCurrentStatus(String currentStatus) {
        this.currentStatus = currentStatus;
    }

    public String getDocID() {
        return docID;
    }

    public void setDocID(String docID) {
        this.docID = docID;
    }

    public String getCorrectStatus() {
        return correctStatus;
    }

    public void setCorrectStatus(String correctStatus) {
        this.correctStatus = correctStatus;
    }

    @Override
    public String toString() {
        return "Model{" +
                "policyNum='" + policyNum + '\'' +
                ", ticket='" + ticket + '\'' +
                ", currentStatus='" + currentStatus + '\'' +
                ", docID='" + docID + '\'' +
                ", correctStatus='" + correctStatus + '\'' +
                ", uwdate='" + uwdate + '\'' +
                '}';
    }

    public String getUwdate() {
        String input = uwdate;

        // Formatter for the input format
        DateTimeFormatter inputFormatter =
                DateTimeFormatter.ofPattern("EEE MMM dd HH:mm:ss z yyyy", Locale.ENGLISH);

        // Formatter for the desired output format
        DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern("M/d/yyyy");

        // Parse and format
        ZonedDateTime dateTime = ZonedDateTime.parse(input, inputFormatter);
        return dateTime.format(outputFormatter);
    }

    public void setUwdate(String uwdate) {
        this.uwdate = uwdate;
    }
}
